from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from app.models import Product, Category, Order, User, Prescription, db
from functools import wraps

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('auth.login', role='admin'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    stats = {
        'total_orders': Order.query.count(),
        'total_products': Product.query.count(),
        'total_users': User.query.filter_by(role='user').count(),
        'pending_prescriptions': Prescription.query.filter_by(status='Pending').count()
    }
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    return render_template('admin/dashboard.html', stats=stats, recent_orders=recent_orders)

@admin_bp.route('/manage_products')
@admin_required
def manage_products():
    products = Product.query.all()
    categories = Category.query.all()
    return render_template('admin/products.html', products=products, categories=categories)

@admin_bp.route('/add_product', methods=['POST'])
@admin_required
def add_product():
    name = request.form.get('name')
    price = request.form.get('price')
    stock = request.form.get('stock')
    category_id = request.form.get('category_id')
    description = request.form.get('description')
    image_url = request.form.get('image_url')
    
    new_product = Product(
        name=name, price=price, stock=stock, 
        category_id=category_id, description=description, image_url=image_url
    )
    db.session.add(new_product)
    db.session.commit()
    flash('Product added successfully', 'success')
    return redirect(url_for('admin.manage_products'))

@admin_bp.route('/manage_orders')
@admin_required
def manage_orders():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin/orders.html', orders=orders)

@admin_bp.route('/update_order_status/<int:order_id>/<status>')
@admin_required
def update_order_status(order_id, status):
    order = Order.query.get_or_404(order_id)
    order.status = status
    db.session.commit()
    flash(f'Order #{order.id} status updated to {status}', 'info')
    return redirect(url_for('admin.manage_orders'))

@admin_bp.route('/manage_prescriptions')
@admin_required
def manage_prescriptions():
    prescriptions = Prescription.query.order_by(Prescription.created_at.desc()).all()
    return render_template('admin/prescriptions.html', prescriptions=prescriptions)

@admin_bp.route('/review_prescription/<int:prescription_id>/<action>')
@admin_required
def review_prescription(prescription_id, action):
    prescription = Prescription.query.get_or_404(prescription_id)
    prescription.status = action
    db.session.commit()
    flash(f'Prescription {action}', 'success')
    return redirect(url_for('admin.manage_prescriptions'))

@admin_bp.route('/manage_categories')
@admin_required
def manage_categories():
    categories = Category.query.all()
    return render_template('admin/categories.html', categories=categories)

@admin_bp.route('/add_category', methods=['POST'])
@admin_required
def add_category():
    name = request.form.get('name')
    if name:
        new_cat = Category(name=name)
        db.session.add(new_cat)
        db.session.commit()
    return redirect(url_for('admin.manage_categories'))

@admin_bp.route('/manage_users')
@admin_required
def manage_users():
    users = User.query.filter_by(role='user').all()
    return render_template('admin/users.html', users=users)

@admin_bp.route('/reports')
@admin_required
def reports():
    from sqlalchemy import func
    total_sales = db.session.query(func.sum(Order.total_amount)).scalar() or 0
    return render_template('admin/reports.html', total_sales=total_sales)

@admin_bp.route('/notifications')
@admin_required
def notifications():
    return render_template('admin/notifications.html')
