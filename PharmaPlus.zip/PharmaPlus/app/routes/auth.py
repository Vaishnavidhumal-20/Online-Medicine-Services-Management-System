from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from flask_mail import Message
from app import db, mail
from app.models import User
from werkzeug.security import generate_password_hash

auth_bp = Blueprint('auth', __name__)

def send_welcome_email(user):
    msg = Message('Welcome to PharmaPlus!',
                  recipients=[user.email])
    msg.body = f"Hello {user.username},\n\nWelcome to our PharmaPlus portal! We are glad to have you with us.\n\nBest Regards,\nPharmaPlus Team"
    try:
        mail.send(msg)
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        flash(f'Note: Could not send welcome email due to configuration issues.', 'warning')
        return False

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        identifier = request.form.get('email') or request.form.get('phone')
        password = request.form.get('password')
        role = request.form.get('role', 'user')
        
        user = User.query.filter(
            ((User.email == identifier) | (User.phone_number == identifier)),
            (User.role == role)
        ).first()
        
        if user and user.check_password(password):
            login_user(user)
            # Send welcome email upon login if email exists
            if user.email:
                send_welcome_email(user)
            
            next_page = request.args.get('next')
            if role == 'admin':
                return redirect(next_page or url_for('admin.dashboard'))
            return redirect(next_page or url_for('user.dashboard'))
        else:
            flash('Login Unsuccessful. Please check credentials', 'danger')
            
    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        phone_number = request.form.get('phone_number')
        password = request.form.get('password')
        role = request.form.get('role', 'user')
        
        user_exists = User.query.filter(
            (User.email == email) | (User.username == username) | (User.phone_number == phone_number)
        ).first()
        
        if user_exists:
            flash('Email, Username or Phone Number already exists', 'danger')
        else:
            new_user = User(username=username, email=email, phone_number=phone_number, role=role)
            new_user.set_password(password)
            db.session.add(new_user)
            db.session.commit()
            
            # Simulated WhatsApp message logic
            # mock_whatsapp_send(phone_number, f"Welcome to PharmaPlus, {username}!")
            
            if email:
                send_welcome_email(new_user)
            
            flash('Account created! You can now login.', 'success')
            return redirect(url_for('auth.login'))
            
    return render_template('auth/register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))
