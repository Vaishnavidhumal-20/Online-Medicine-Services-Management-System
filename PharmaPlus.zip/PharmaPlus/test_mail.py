from app import create_app, mail
from flask_mail import Message
import os
from dotenv import load_dotenv

load_dotenv()

app = create_app()

with app.app_context():
    print(f"Testing Mail with: {app.config['MAIL_USERNAME']}")
    msg = Message('Test Email',
                  recipients=[app.config['MAIL_USERNAME']])
    msg.body = "This is a test email from PharmaPlus setup."
    try:
        mail.send(msg)
        print("Success! Email sent.")
    except Exception as e:
        print(f"Failed to send email: {e}")
        print("\nPossible reasons:")
        print("1. Your .env file is not updated with real credentials.")
        print("2. You haven't used a Google 'App Password' (Gmail requires this).")
        print("3. Your firewall/network is blocking port 587.")
