from app import create_app, db
from app.models import Category, Product, User
from werkzeug.security import generate_password_hash

app = create_app()

def seed():
    with app.app_context():
        db.create_all()
        # Create categories if they don't exist
        cats = ['Serum', 'Skincare', 'Syrup', 'Healthcare', 'Mobility & Elderly Care', 'Baby Care']
        for c_name in cats:
            if not Category.query.filter_by(name=c_name).first():
                db.session.add(Category(name=c_name))
        db.session.commit()

        # Create Admin
        if not User.query.filter_by(email='admin@pharmaplus.com').first():
            admin = User(username='admin', email='admin@pharmaplus.com', role='admin')
            admin.set_password('admin123')
            db.session.add(admin)

        # Create Sample Products
        c1 = Category.query.filter_by(name='Healthcare').first()
        c2 = Category.query.filter_by(name='Skincare').first()
        c3 = Category.query.filter_by(name='Syrup').first()
        c4 = Category.query.filter_by(name='Serum').first()

        products = [
            {'name': 'Paracetamol 500mg', 'price': 45.00, 'stock': 100, 'cat': c1, 'img': 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=600'},
            {'name': 'Vitamin C 1000mg Tablets', 'price': 349.00, 'stock': 80, 'cat': c1, 'img': 'https://images.unsplash.com/photo-1616671285338-7694f87a32fd?auto=format&fit=crop&q=80&w=600'},
            {'name': 'Zinc+ Multivitamin', 'price': 499.00, 'stock': 60, 'cat': c1, 'img': 'https://images.unsplash.com/photo-1550572017-ed303789498a?auto=format&fit=crop&q=80&w=600'},
            
            {'name': 'Hydrating Facial Serum', 'price': 899.00, 'stock': 30, 'cat': c4, 'img': 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=600'},
            {'name': 'Vitamin C Face Serum', 'price': 749.00, 'stock': 45, 'cat': c4, 'img': 'https://images.unsplash.com/photo-1611080626919-7cf5a9caab5b?auto=format&fit=crop&q=80&w=600'},
            {'name': 'Retinol Night Serum', 'price': 1200.00, 'stock': 20, 'cat': c4, 'img': 'https://images.unsplash.com/photo-1631733307627-5d3369a30485?auto=format&fit=crop&q=80&w=600'},

            {'name': 'Aloe Vera Moisturizer', 'price': 250.00, 'stock': 100, 'cat': c2, 'img': 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&q=80&w=600'},
            {'name': 'Sunscreen SPF 50', 'price': 599.00, 'stock': 55, 'cat': c2, 'img': 'https://images.unsplash.com/photo-1556229010-6c3f2c9ca47b?auto=format&fit=crop&q=80&w=600'},
            {'name': 'Cleansing Face Wash', 'price': 199.00, 'stock': 75, 'cat': c2, 'img': 'https://images.unsplash.com/photo-1556228515-01ff1ee3976b?auto=format&fit=crop&q=80&w=600'},

            {'name': 'Cough Relief Syrup', 'price': 120.00, 'stock': 40, 'cat': c3, 'img': 'https://images.unsplash.com/photo-1585435557343-3b092031a831?auto=format&fit=crop&q=80&w=600'},
            {'name': 'Iron Tonic Syrup', 'price': 180.00, 'stock': 35, 'cat': c3, 'img': 'https://images.unsplash.com/photo-1471864190281-a93a307246de?auto=format&fit=crop&q=80&w=600'},
            {'name': 'Digestive Enzyme Syrup', 'price': 150.00, 'stock': 50, 'cat': c3, 'img': 'https://images.unsplash.com/photo-1587854692152-cbe660dbbb88?auto=format&fit=crop&q=80&w=600'},
        ]

        for p in products:
            if not Product.query.filter_by(name=p['name']).first():
                db.session.add(Product(
                    name=p['name'], price=p['price'], stock=p['stock'], 
                    category_id=p['cat'].id, image_url=p['img'],
                    description=f"High quality {p['name']} for your health needs."
                ))
        
        db.session.commit()
        print("Database Seeded Successfully!")

if __name__ == '__main__':
    seed()
