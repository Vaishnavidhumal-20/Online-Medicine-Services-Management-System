from app import create_app
from app.models import Product, Category, db

app = create_app()
with app.app_context():
    products = Product.query.all()
    print(f"Total products: {len(products)}")
    for p in products:
        print(f"ID: {p.id}, Name: {p.name}, Image: {p.image_url}")
    
    categories = Category.query.all()
    print("\nCategories:")
    for c in categories:
        print(f"ID: {c.id}, Name: {c.name}")
